var rockButton;
var paperButton;
var scissorButton;
let player1;
let player2;
let turn = "player1";

window.onload = function () {
    rockButton = document.getElementById("rockButton");
    paperButton = document.getElementById("divpaper");
    scissorButton = document.getElementById("divscissor");

    rockButton.addEventListener("click", clickRock);
    paperButton.addEventListener("click", clickPaper);
    scissorButton.addEventListener("click", clickScissor);
};

function turnSwitch() {
    if (turn === "player1") {
        turn = "player2";
        document.querySelector("h1").innerHTML = "Speler 2, kies je optie!";
    } else {
        turn = "player1";
        checkWinner();
    }
}

function clickRock() {
    if (turn === "player1") {
        player1 = "rock";
    } else {
        player2 = "rock";
    }
    turnSwitch();
}

function clickPaper() {
    if (turn === "player1") {
        player1 = "paper";
    } else {
        player2 = "paper";
    }
    turnSwitch();
}

function clickScissor() {
    if (turn === "player1") {
        player1 = "scissor";
    } else {
        player2 = "scissor";
    }
    turnSwitch();
}

function checkWinner() {
    document.getElementById("buttons").style.visibility = "hidden";

    if (player1 === player2) {
        document.querySelector("h1").innerHTML = "Gelijkspel! Druk een toets voor een nieuw spel";
    } else if (player1 === "rock" && player2 === "scissor") {
        player1Winner();
    } else if (player1 === "paper" && player2 === "rock") {
        player1Winner();
    } else if (player1 === "scissor" && player2 === "paper") {
        player1Winner();
    } else {
        document.querySelector("h1").innerHTML = "Speler 2 wint! Druk een toets voor een nieuw spel";
    }
    window.addEventListener("keypress", resetGame);
}

function player1Winner() {
    document.querySelector("h1").innerHTML = "Speler 1 wint! Druk een toets voor een nieuw spel";
}

function resetGame() {
    player1 = "";
    player2 = "";
    document.querySelector("h1").innerHTML = "Speler 1, kies je optie!";
    document.getElementById("buttons").style.visibility = "visible";
}